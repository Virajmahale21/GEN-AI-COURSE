import os
import json
import arxiv
from config import PAPERS_JSON_PATH, CS_CATEGORIES

def fetch_arxiv_cs_papers(max_results=500):
    """
    Fetches Computer Science papers directly from the official arXiv API.
    Filter: cs.AI, cs.CL, cs.CV, cs.LG
    """
    print(f"Fetching top {max_results} Computer Science papers from arXiv API...")
    query = " OR ".join([f"cat:{cat}" for cat in CS_CATEGORIES])
    
    search = arxiv.Search(
        query=query,
        max_results=max_results,
        sort_by=arxiv.SortCriterion.SubmittedDate
    )
    
    papers = []
    client = arxiv.Client()
    
    try:
        results = list(client.results(search))
        for res in results:
            paper_data = {
                "paper_id": res.entry_id.split("/")[-1],
                "title": res.title.strip(),
                "authors": [author.name for author in res.authors],
                "abstract": res.summary.replace("\n", " ").strip(),
                "categories": res.categories,
                "primary_category": res.primary_category,
                "pdf_url": res.pdf_url,
                "published": str(res.published)[:10],
                "year": str(res.published.year),
                "doi": res.doi if res.doi else f"10.48550/arXiv.{res.entry_id.split('/')[-1]}"
            }
            papers.append(paper_data)
            
        print(f"Successfully fetched {len(papers)} CS papers from arXiv!")
    except Exception as e:
        print(f"Warning: Failed to fetch online arXiv data ({e}). Generating high-quality local CS dataset.")
        papers = get_fallback_cs_papers()
        
    with open(PAPERS_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(papers, f, indent=4)
        
    return papers

def get_fallback_cs_papers():
    return [
        {
            "paper_id": "1706.03762",
            "title": "Attention Is All You Need",
            "authors": ["Ashish Vaswani", "Noam Shazeer", "Niki Parmar", "Jakob Uszkoreit", "Llion Jones", "Aidan N. Gomez", "Lukasz Kaiser", "Illia Polosukhin"],
            "abstract": "The dominant sequence transduction models are based on complex recurrent or convolutional neural networks in an encoder-decoder configuration. We propose the Transformer, a novel neural network architecture based solely on attention mechanisms, dispensing with recurrence and convolutions entirely. Experiments on two machine translation tasks show these models to be superior in quality while being more parallelizable and requiring significantly less time to train.",
            "categories": ["cs.CL", "cs.LG"],
            "primary_category": "cs.CL",
            "pdf_url": "https://arxiv.org/pdf/1706.03762.pdf",
            "published": "2017-06-12",
            "year": "2017",
            "doi": "10.48550/arXiv.1706.03762"
        },
        {
            "paper_id": "2010.11929",
            "title": "An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale",
            "authors": ["Alexey Dosovitskiy", "Lucas Beyer", "Alexander Kolesnikov", "Dirk Weissenborn", "Xiaohua Zhai", "Thomas Unterthiner", "Mostafa Dehghani", "Matthias Minderer", "Georg Heigold", "Sylvain Gelly", "Jakob Uszkoreit", "Neil Houlsby"],
            "abstract": "While the Transformer architecture has become the de-facto standard for natural language processing tasks, its applications to computer vision remain limited. In vision, attention is either applied in conjunction with convolutional networks, or used to replace certain components of convolutional networks while keeping their overall structure in place. We show that this reliance on CNNs is not necessary and a pure transformer applied directly to sequences of image patches can perform very well on image classification tasks.",
            "categories": ["cs.CV", "cs.LG"],
            "primary_category": "cs.CV",
            "pdf_url": "https://arxiv.org/pdf/2010.11929.pdf",
            "published": "2020-10-22",
            "year": "2020",
            "doi": "10.48550/arXiv.2010.11929"
        },
        {
            "paper_id": "2302.13971",
            "title": "LLaMA: Open and Efficient Foundation Language Models",
            "authors": ["Hugo Touvron", "Thibaut Lavril", "Gautier Izacard", "Xavier Martinet", "Marie-Anne Lachaux", "Timothée Lacroix", "Baptiste Rozière", "Naman Goyal", "Eric Hambro", "Faisal Azhar", "Aurelien Rodriguez", "Armand Joulin", "Edouard Grave", "Guillaume Lample"],
            "abstract": "We introduce LLaMA, a collection of foundation language models ranging from 7B to 65B parameters. We train our models on trillions of tokens, and show that it is possible to train state-of-the-art models using publicly available datasets exclusively, without resorting to proprietary and inaccessible datasets. In particular, LLaMA-13B outperforms GPT-3 (175B) on most benchmarks, despite being 10x smaller.",
            "categories": ["cs.CL", "cs.AI"],
            "primary_category": "cs.CL",
            "pdf_url": "https://arxiv.org/pdf/2302.13971.pdf",
            "published": "2023-02-27",
            "year": "2023",
            "doi": "10.48550/arXiv.2302.13971"
        }
    ]

if __name__ == "__main__":
    fetch_arxiv_cs_papers(max_results=300)
