﻿from langchain.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.document_loaders.csv_loader import CSVLoader
from langchain.document_loaders import PyPDFLoader, TextLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import HuggingFaceInstructEmbeddings
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from langchain.schema.messages import HumanMessage, SystemMessage
import os

from dotenv import load_dotenv

load_dotenv()  # take environment variables from .env (especially openai api key)

# Create Gemini Multimodal model
llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=os.environ.get("GOOGLE_API_KEY", "dummy"), temperature=0.1)
# # Initialize instructor embeddings using the Hugging Face model
instructor_embeddings = HuggingFaceInstructEmbeddings(
    model_name="hkunlp/instructor-large"
)
vectordb_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "faiss_index")


def create_vector_db():
    # Load data from FAQ sheet
    loader = CSVLoader(file_path="dataset.csv", source_column="prompt")
    data = loader.load()

    # Create a FAISS instance for vector database from 'data'
    vectordb = FAISS.from_documents(documents=data, embedding=instructor_embeddings)

    # Save vector database locally
    vectordb.save_local(vectordb_file_path)

def get_vector_db():
    if os.path.exists(vectordb_file_path):
        return FAISS.load_local(vectordb_file_path, instructor_embeddings)
    return None

def load_document(file_path, file_type):
    if file_type == 'csv':
        if "dataset.csv" in file_path:
            loader = CSVLoader(file_path=file_path, source_column="prompt")
            return loader.load()
        else:
            loader = CSVLoader(file_path=file_path)
            return loader.load()
    elif file_type == 'pdf':
        loader = PyPDFLoader(file_path)
        pages = loader.load_and_split()
        return pages
    elif file_type in ['text', 'txt']:
        loader = TextLoader(file_path)
        docs = loader.load()
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        return text_splitter.split_documents(docs)
    else:
        raise ValueError(f"Unsupported file type: {file_type}")

def update_vector_db(file_path, file_type, file_hash):
    docs = load_document(file_path, file_type)
    
    # Metadata tagging for source tracking and strict requirements
    for i, doc in enumerate(docs):
        doc.metadata["source_file"] = os.path.basename(file_path)
        doc.metadata["file_type"] = file_type
        doc.metadata["file_hash"] = file_hash
        doc.metadata["chunk_index"] = i
        
    vectordb = get_vector_db()
    if vectordb:
        ids = vectordb.add_documents(docs)
        vectordb.save_local(vectordb_file_path)
    else:
        # Create a new index if it doesn't exist
        import uuid
        ids = [str(uuid.uuid4()) for _ in docs]
        # FAISS.from_documents doesn't easily return IDs, so we do it explicitly
        vectordb = FAISS.from_documents(documents=docs, embedding=instructor_embeddings, ids=ids)
        vectordb.save_local(vectordb_file_path)
        
    return ids

def delete_from_vector_db(chunk_ids):
    if not chunk_ids:
        return True
    vectordb = get_vector_db()
    if vectordb:
        try:
            vectordb.delete(chunk_ids)
            vectordb.save_local(vectordb_file_path)
            return True
        except Exception as e:
            print(f"Error deleting chunks from FAISS: {e}")
            return False
    return False


def get_qa_chain():
    # Load the vector database from the local folder
    vectordb = FAISS.load_local(vectordb_file_path, instructor_embeddings)

    # Create a retriever for querying the vector database
    retriever = vectordb.as_retriever(score_threshold=0.7)

    prompt_template = """Given the following context and a question, generate an answer based on this context only.
    In the answer try to provide as much text as possible from "response" section in the source document context without making much changes.
    If the answer is not found in the context, kindly state "I don't know." Don't try to make up an answer.

    CONTEXT: {context}

    QUESTION: {question}"""

    PROMPT = PromptTemplate(
        template=prompt_template, input_variables=["context", "question"]
    )

    chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        input_key="query",
        return_source_documents=True,
        chain_type_kwargs={"prompt": PROMPT},
    )
    return chain

import base64

def get_multimodal_answer(question, image_bytes, chat_history):
    vectordb = get_vector_db()
    context = ""
    source_docs = []
    
    if vectordb:
        retriever = vectordb.as_retriever(score_threshold=0.7)
        # Search for context relevant to the question
        docs = retriever.get_relevant_documents(question)
        context = "\n".join([d.page_content for d in docs])
        source_docs = docs
        
    system_instruction = f"""You are a multi-modal AI assistant for Nullclass. 
Use the following retrieved context to answer the user's questions. 
If they upload an image, analyze it carefully. Combine your visual analysis with the context provided to give a highly accurate, evidence-based response.

Context: {context}
"""

    messages = [SystemMessage(content=system_instruction)]
    
    # Add chat history for context
    for msg in chat_history:
        if msg["role"] == "user":
            messages.append(HumanMessage(content=msg["content"]))
        else:
            messages.append(SystemMessage(content=msg["content"]))
            
    # Add current question and image
    content = [{"type": "text", "text": question}]
    if image_bytes:
        encoded_image = base64.b64encode(image_bytes).decode("utf-8")
        content.append({
            "type": "image_url", 
            "image_url": {"url": f"data:image/jpeg;base64,{encoded_image}"}
        })
        
    messages.append(HumanMessage(content=content))
    
    response = llm(messages)
    
    return {
        "result": response.content,
        "source_documents": source_docs
    }

if __name__ == "__main__":
    # Test creation
    # create_vector_db()
    pass
