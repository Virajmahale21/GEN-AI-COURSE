﻿import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
VECTORSTORE_DIR = os.path.join(BASE_DIR, "vectorstore")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(VECTORSTORE_DIR, exist_ok=True)

PAPERS_JSON_PATH = os.path.join(DATA_DIR, "cs_papers.json")
FAISS_INDEX_PATH = os.path.join(VECTORSTORE_DIR, "faiss_index")
METADATA_PATH = os.path.join(VECTORSTORE_DIR, "metadata.pkl")

# Subfields in Computer Science
CS_CATEGORIES = ["cs.AI", "cs.CL", "cs.CV", "cs.LG"]

# Embedding & LLM Settings
EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
OLLAMA_MODEL_NAME = "llama3.2:3b"  # Fallback to qwen2.5:3b or Gemini API if needed
TOP_K = 4
SIMILARITY_THRESHOLD = 1.3  # L2 Distance threshold for FAISS
