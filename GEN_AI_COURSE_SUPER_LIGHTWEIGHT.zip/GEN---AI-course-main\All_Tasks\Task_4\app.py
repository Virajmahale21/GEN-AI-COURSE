﻿import streamlit as st
import os
import json
from dotenv import load_dotenv

from retriever import ArxivRetriever
from llm_explainer import LLMExplainer
from conversation_memory import ConversationMemory
from visualizer import generate_mermaid_concept_graph, create_category_distribution_chart
from config import CS_CATEGORIES

load_dotenv()

st.set_page_config(page_title="arXiv CS Domain Expert Chatbot", page_icon="🤖", layout="wide")

@st.cache_resource
def load_services():
    retriever = ArxivRetriever()
    explainer = LLMExplainer()
    return retriever, explainer

retriever_service, llm_service = load_services()

# Session State Initializations
if "memory" not in st.session_state:
    st.session_state.memory = ConversationMemory(max_turns=5)

if "chat_display" not in st.session_state:
    st.session_state.chat_display = []

st.title("💬 ArxivExpertChatbot")
st.markdown("*Powered by RAG, FAISS Vector Indexing & Open-Source LLM (Llama 3.2 / Qwen 2.5)*")

# 4-Tab Interface
tab1, tab2, tab3, tab4 = st.tabs([
    "💬 Expert Chatbot", 
    "🔍 arXiv Paper Explorer", 
    "📝 Paper Analyzer", 
    "📊 Concept Visualizer"
])

# ---------------------------------------------------------
# TAB 1: EXPERT CHATBOT
# ---------------------------------------------------------
with tab1:
    st.sidebar.title("Chat Settings")
    explanation_level = st.sidebar.select_slider(
        "Concept Explanation Level:",
        options=["Beginner", "Intermediate", "Advanced"],
        value="Intermediate"
    )
    
    if st.sidebar.button("Clear Chat History"):
        st.session_state.memory.clear()
        st.session_state.chat_display = []
        st.sidebar.success("Chat history cleared!")

    st.markdown("### Ask Complex Questions or Request Concept Explanations")
    
    # Display Chat History
    for msg in st.session_state.chat_display:
        avatar = "🧑‍💻" if msg["role"] == "user" else "🤖"
        with st.chat_message(msg["role"], avatar=avatar):
            st.markdown(msg["content"])
            
    if query := st.chat_input("Ask about transformers, self-attention, computer vision, or machine learning..."):
        # User turn
        st.session_state.chat_display.append({"role": "user", "content": query})
        st.session_state.memory.add_turn("user", query)
        
        with st.chat_message("user", avatar="🧑‍💻"):
            st.markdown(query)
            
        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner("Searching arXiv Computer Science database & reasoning..."):
                retrieved_papers, status = retriever_service.retrieve_relevant_papers(query)
                history_text = st.session_state.memory.get_formatted_history()
                
                answer = llm_service.generate_rag_response(
                    query=query, 
                    retrieved_papers=retrieved_papers, 
                    conversation_history=history_text,
                    level=explanation_level
                )
                
                st.markdown(answer)
                st.session_state.chat_display.append({"role": "assistant", "content": answer})
                st.session_state.memory.add_turn("assistant", answer)

# ---------------------------------------------------------
# TAB 2: ARXIV PAPER EXPLORER
# ---------------------------------------------------------
with tab2:
    st.header("🔍 arXiv Paper Search & Explorer")
    st.markdown("Search Computer Science research papers by title, author, category, year, or keywords.")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        search_title = st.text_input("Title Keyword:")
        search_category = st.selectbox("Category:", ["All"] + CS_CATEGORIES)
    with col2:
        search_author = st.text_input("Author Name:")
        search_year = st.selectbox("Publication Year:", ["All"] + [str(y) for y in range(2025, 2014, -1)])
    with col3:
        search_keyword = st.text_input("Abstract Keyword / Topic:")
        
    if st.button("Search Papers"):
        matches = retriever_service.search_papers_by_metadata(
            title_query=search_title,
            author_query=search_author,
            category=search_category,
            year=search_year,
            keyword_query=search_keyword
        )
        
        st.success(f"Found {len(matches)} matching papers.")
        for paper in matches:
            with st.expander(f"📄 {paper['title']} ({paper['year']}) ➝ {', '.join(paper['categories'])}"):
                st.write(f"**Authors:** {', '.join(paper['authors'])}")
                st.write(f"**arXiv ID:** {paper['paper_id']} | **DOI:** {paper['doi']}")
                st.write(f"**Abstract:** {paper['abstract']}")
                st.markdown(f"[📥 Download PDF]({paper['pdf_url']})")

# ---------------------------------------------------------
# TAB 3: PAPER ANALYZER & SUMMARIZER
# ---------------------------------------------------------
with tab3:
    st.header("📝 8-Part Research Paper Summarizer")
    all_papers = list(retriever_service.metadata_store.values())
    if all_papers:
        paper_titles = {p["title"]: p for p in all_papers}
        selected_title = st.selectbox("Select a Paper to Analyze:", list(paper_titles.keys()))
        
        if st.button("Generate Structured 8-Part Summary"):
            selected_paper = paper_titles[selected_title]
            with st.spinner("Analyzing research paper structure..."):
                summary = llm_service.generate_paper_summary(selected_paper)
                st.markdown(summary)
    else:
        st.info("No papers available in metadata store. Run data_prep.py and vectorstore.py first.")

# ---------------------------------------------------------
# TAB 4: CONCEPT VISUALIZER
# ---------------------------------------------------------
with tab4:
    st.header("📊 Concept Relationship & Topic Visualizer")
    all_papers = list(retriever_service.metadata_store.values())
    
    if all_papers:
        st.subheader("Topic Frequency & Category Distribution")
        fig = create_category_distribution_chart(all_papers)
        st.plotly_chart(fig, use_container_width=True)
        
        st.markdown("---")
        st.subheader("Concept Map Generator")
        paper_titles = {p["title"]: p for p in all_papers}
        selected_paper_vis = st.selectbox("Select Paper for Concept Graph:", list(paper_titles.keys()), key="vis_select")
        
        if selected_paper_vis:
            paper_meta = paper_titles[selected_paper_vis]
            mermaid_code = generate_mermaid_concept_graph(paper_meta["title"], paper_meta["keywords"])
            
            st.markdown("**Mermaid Concept Dependency Graph Code:**")
            st.code(mermaid_code, language="mermaid")