from vectorstore import load_vector_store
from config import TOP_K, SIMILARITY_THRESHOLD

class ArxivRetriever:
    def __init__(self):
        self.db, self.metadata_store = load_vector_store()

    def retrieve_relevant_papers(self, query, top_k=TOP_K):
        """Top-K semantic search with similarity threshold checks and safeguards."""
        if not self.db:
            return [], "Vector database unavailable."
            
        results = self.db.similarity_search_with_score(query, k=top_k)
        
        valid_papers = []
        for doc, score in results:
            # Check L2 distance threshold
            if score <= SIMILARITY_THRESHOLD:
                valid_papers.append({
                    "document": doc,
                    "score": score,
                    "metadata": doc.metadata
                })
                
        if not valid_papers:
            return [], "No sufficiently relevant Computer Science papers found in the database for this query."
            
        return valid_papers, "Success"

    def search_papers_by_metadata(self, title_query="", author_query="", category="All", year="All", keyword_query=""):
        """Multi-attribute paper explorer search."""
        matches = []
        for paper_id, meta in self.metadata_store.items():
            # Check title
            if title_query and title_query.lower() not in meta["title"].lower():
                continue
            # Check author
            if author_query and not any(author_query.lower() in a.lower() for a in meta["authors"]):
                continue
            # Check category
            if category != "All" and category not in meta["categories"]:
                continue
            # Check year
            if year != "All" and str(meta["year"]) != str(year):
                continue
            # Check keyword
            if keyword_query and keyword_query.lower() not in meta["abstract"].lower() and keyword_query.lower() not in meta["title"].lower():
                continue
                
            matches.append(meta)
            
        return matches

if __name__ == "__main__":
    retriever = ArxivRetriever()
    papers, status = retriever.retrieve_relevant_papers("attention mechanism transformer")
    print(f"Status: {status}, Found {len(papers)} papers.")
