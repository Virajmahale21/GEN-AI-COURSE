import re
from collections import Counter

class InformationExtractor:
    def __init__(self):
        # Common stop words for keyword extraction
        self.stopwords = set([
            "a", "an", "the", "and", "or", "but", "if", "because", "as", "until",
            "while", "of", "at", "by", "for", "with", "about", "against", "between",
            "into", "through", "during", "before", "after", "above", "below", "to",
            "from", "up", "upon", "down", "in", "out", "on", "off", "over", "under",
            "again", "further", "then", "once", "here", "there", "when", "where",
            "why", "how", "all", "any", "both", "each", "few", "more", "most",
            "other", "some", "such", "no", "nor", "not", "only", "own", "same",
            "so", "than", "too", "very", "s", "t", "can", "will", "just", "don",
            "should", "now", "we", "propose", "show", "using", "used", "paper",
            "results", "model", "models", "method", "methods", "approach", "task"
        ])

    def extract_keywords(self, text, top_n=8):
        """Extract key technical concepts from abstract text using n-gram frequency."""
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        filtered_words = [w for w in words if w not in self.stopwords]
        
        # Bigrams & Unigrams
        bigrams = [f"{filtered_words[i]} {filtered_words[i+1]}" for i in range(len(filtered_words)-1)]
        
        freq = Counter(filtered_words + bigrams)
        return [item[0] for item in freq.most_common(top_n)]

    def extract_paper_metadata(self, paper_dict):
        """Standardized information extraction from paper record."""
        abstract = paper_dict.get("abstract", "")
        title = paper_dict.get("title", "")
        
        extracted_keywords = self.extract_keywords(f"{title} {abstract}")
        
        return {
            "paper_id": paper_dict.get("paper_id", "Unknown"),
            "title": title,
            "authors": paper_dict.get("authors", []),
            "abstract": abstract,
            "categories": paper_dict.get("categories", []),
            "primary_category": paper_dict.get("primary_category", "cs.AI"),
            "year": paper_dict.get("year", "2023"),
            "published": paper_dict.get("published", "Unknown"),
            "doi": paper_dict.get("doi", "N/A"),
            "pdf_url": paper_dict.get("pdf_url", ""),
            "keywords": extracted_keywords
        }

if __name__ == "__main__":
    extractor = InformationExtractor()
    sample = {
        "paper_id": "1706.03762",
        "title": "Attention Is All You Need",
        "abstract": "We propose the Transformer, a novel neural network architecture based solely on attention mechanisms.",
        "authors": ["Vaswani et al."],
        "year": "2017"
    }
    print(extractor.extract_paper_metadata(sample))
