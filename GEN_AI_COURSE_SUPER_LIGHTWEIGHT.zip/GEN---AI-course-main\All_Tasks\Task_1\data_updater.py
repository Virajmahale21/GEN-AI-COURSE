﻿import os
import json
import time
import shutil
import hashlib
import logging
from datetime import datetime
import schedule
from dotenv import load_dotenv

from langchain_helper import update_vector_db, delete_from_vector_db

# Ensure directories exist
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs"), exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), "archive"), exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), "config"), exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_data/csv"), exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_data/pdf"), exist_ok=True)
os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_data/text"), exist_ok=True)

logging.basicConfig(
    filename=os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs/updater.log"),
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

load_dotenv()

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config/sources.json")
HASH_STORE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "doc_hashes.json")
ARCHIVE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "archive")

# Default config if not exists
if not os.path.exists(CONFIG_PATH):
    default_config = {
        "sources": [
            {"type": "csv", "path": os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_data/csv")},
            {"type": "pdf", "path": os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_data/pdf")},
            {"type": "text", "path": os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_data/text")}
        ]
    }
    with open(CONFIG_PATH, "w") as f:
        json.dump(default_config, f, indent=4)


def get_file_hash(file_path):
    hasher = hashlib.sha256()
    with open(file_path, 'rb') as f:
        buf = f.read()
        hasher.update(buf)
    return hasher.hexdigest()

def load_hashes():
    if os.path.exists(HASH_STORE):
        with open(HASH_STORE, 'r') as f:
            return json.load(f)
    return {}

def save_hashes(hashes):
    with open(HASH_STORE, 'w') as f:
        json.dump(hashes, f, indent=4)

def process_sources():
    logging.info("Starting knowledge base update cycle.")
    
    with open(CONFIG_PATH, 'r') as f:
        config = json.load(f)

    hashes = load_hashes()
    
    for source in config.get("sources", []):
        src_type = source.get("type")
        src_path = source.get("path")
        
        if not os.path.exists(src_path):
            continue
            
        for filename in os.listdir(src_path):
            file_path = os.path.join(src_path, filename)
            if not os.path.isfile(file_path):
                continue
                
            file_hash = get_file_hash(file_path)
            logging.info(f"Detected file: {filename}")
            
            is_new = False
            is_modified = False
            
            if filename in hashes:
                if hashes[filename]["hash"] != file_hash:
                    logging.info(f"Status for {filename}: MODIFIED (previous hash: {hashes[filename]['hash']}, new hash: {file_hash})")
                    is_modified = True
                else:
                    logging.info(f"Status for {filename}: ALREADY PROCESSED. Skipping.")
                    # Move to archive if it's somehow still in new_data
                    try:
                        shutil.move(file_path, os.path.join(ARCHIVE_DIR, filename))
                    except Exception:
                        pass
                    continue
            else:
                logging.info(f"Status for {filename}: NEW")
                is_new = True
                
            try:
                # If modified, remove old chunks first without rebuilding DB
                if is_modified and "chunk_ids" in hashes[filename]:
                    old_ids = hashes[filename]["chunk_ids"]
                    if old_ids:
                        delete_from_vector_db(old_ids)
                        logging.info(f"Removed {len(old_ids)} old chunks for {filename}.")
                
                # Extract, chunk, and embed
                new_chunk_ids = update_vector_db(file_path, src_type, file_hash)
                
                # Move to archive
                archive_path = os.path.join(ARCHIVE_DIR, filename)
                shutil.copy(file_path, archive_path)
                os.remove(file_path)
                
                # Update persistent metadata tracking
                hashes[filename] = {
                    "hash": file_hash,
                    "last_updated": datetime.now().isoformat(),
                    "source_type": src_type,
                    "chunk_ids": new_chunk_ids
                }
                
                logging.info(f"Successfully processed {filename}: {len(new_chunk_ids)} chunks created and embeddings added to FAISS.")
                logging.info(f"Successful archive operation: Moved {filename} to archive/.")
            except Exception as e:
                logging.error(f"Error processing {filename}. File remains in new_data/. Error: {str(e)}")

    save_hashes(hashes)
    logging.info("Knowledge base update cycle complete.")

if __name__ == "__main__":
    interval = int(os.getenv("UPDATE_INTERVAL_MINUTES", "60"))
    print(f"Starting updater service. Interval: {interval} minutes.")
    
    # Run once immediately
    process_sources()
    
    # Schedule
    schedule.every(interval).minutes.do(process_sources)
    
    while True:
        schedule.run_pending()
        time.sleep(1)
