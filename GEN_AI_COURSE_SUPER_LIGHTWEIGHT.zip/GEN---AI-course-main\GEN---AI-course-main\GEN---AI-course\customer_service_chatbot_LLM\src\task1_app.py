import streamlit as st
import os
import json
from langchain_helper import get_qa_chain, create_vector_db

st.set_page_config(page_title="DynamicKBChatbot", page_icon="📚", layout="wide")

st.title("📚 DynamicKBChatbot")
st.markdown("*Task 1: Dynamically Expanding Knowledge Base System*")

# Knowledge Base Status Section
st.sidebar.title("Knowledge Base Status")
doc_count = 0
last_updated = "Never"

hash_file = "../doc_hashes.json"
if os.path.exists(hash_file):
    with open(hash_file, "r") as f:
        hashes = json.load(f)
        doc_count = len(hashes)
        if doc_count > 0:
            latest = max(doc["last_updated"] for doc in hashes.values())
            last_updated = latest[:16].replace("T", " ")

st.sidebar.markdown(f"**Documents processed:** {doc_count}")
st.sidebar.markdown(f"**Last updated:** {last_updated}")
st.sidebar.markdown("**Status:** Up to date")

btn = st.sidebar.button("Create/Reset Knowledgebase")
if btn:
    create_vector_db()
    st.sidebar.success("Reset Knowledgebase complete!")

question = st.text_input("Question: ")

if question:
    chain = get_qa_chain()
    if chain is None:
        st.error("Knowledge base not found. Please create/update it first.")
    else:
        with st.spinner("Searching Knowledge Base..."):
            response = chain(question)

            st.header("Answer")
            st.write(response["result"])
            
            # Display source information
            if "source_documents" in response and response["source_documents"]:
                st.subheader("Retrieved Sources:")
                seen_sources = set()
                for doc in response["source_documents"]:
                    source_file = doc.metadata.get("source_file") or doc.metadata.get("source") or "Unknown"
                    if source_file not in seen_sources:
                        st.write(f"- {source_file}")
                        seen_sources.add(source_file)
