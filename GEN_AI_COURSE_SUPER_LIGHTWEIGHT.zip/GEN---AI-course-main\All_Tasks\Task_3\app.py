﻿import streamlit as st
import os
from dotenv import load_dotenv

from medical_ner import MedicalNER
from retriever import MedicalRetriever
from llm_service import LLMService

load_dotenv()

st.set_page_config(page_title="MedChatbot (Task 3)", page_icon="🏥", layout="wide")


st.title("💬 MedChatbot")

st.markdown("*Disclaimer: For informational purposes only. Do not use this for medical emergencies. Always consult a professional.*")

@st.cache_resource
def load_models(cache_buster=1):
    ner = MedicalNER()
    retriever = MedicalRetriever()
    return ner, retriever

with st.spinner("Initializing Medical NER & Embedding Models..."):
    ner_service, retriever_service = load_models(cache_buster=2)

# Chat History
if "task3_messages" not in st.session_state:
    st.session_state.task3_messages = [{"role": "assistant", "content": "Hello! I am MedChatbot. How can I assist you with medical queries today?"}]

# Layout
col1, col2 = st.columns([3, 1])

with col1:
    # Display chat history
    for msg in st.session_state.task3_messages:
        avatar = "🧑‍💻" if msg["role"] == "user" else "🤖"
        with st.chat_message(msg["role"], avatar=avatar):
            st.markdown(msg["content"])
            if msg.get("image"):
                st.image(msg["image"], width=300)

with col2:
    st.subheader("🧬 Medical Entities")
    entity_placeholder = st.empty()
    
    st.subheader("🖼️ Image Upload")
    image_file = st.file_uploader("Upload Medical Image (Optional)", type=["jpg", "jpeg", "png"])
    image_bytes = None
    if image_file:
        image_bytes = image_file.getvalue()
        st.image(image_bytes, caption="Uploaded Image", use_column_width=True)

if query := st.chat_input("Ask a medical question..."):
    # Append user message
    st.session_state.task3_messages.append({"role": "user", "content": query, "image": image_bytes})
    with col1:
        with st.chat_message("user", avatar="🧑‍💻"):
            st.markdown(query)
            if image_bytes:
                st.image(image_bytes, width=300)
                
    # 1. Run NER
    entities = ner_service.extract_and_map(query)
    with col2:
        with entity_placeholder.container():
            st.write("**Disease/Condition:**", ", ".join(entities.get("Disease/Condition", [])) or "None")
            st.write("**Symptom:**", ", ".join(entities.get("Symptom", [])) or "None")
            st.write("**Treatment:**", ", ".join(entities.get("Treatment", [])) or "None")

    # 2. Retrieval
    with col1:
        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner("Retrieving MedQuAD knowledge..."):
                retrieved_docs, status_msg = retriever_service.retrieve(query)
                
                if not retrieved_docs:
                    st.warning(status_msg)
                    final_answer = status_msg
                else:
                    # 3. LLM Generation
                    with st.spinner("Generating safe medical response..."):
                        llm_service = LLMService()
                        final_answer = llm_service.generate_response(
                            query=query, 
                            image_bytes=image_bytes, 
                            retrieved_docs=retrieved_docs, 
                            chat_history=st.session_state.task3_messages[:-1]
                        )
                    
                    st.markdown(final_answer)
                    
                    # 4. Source Citation
                    st.markdown("---")
                    st.markdown("**NIH Sources Retrieved:**")
                    seen_sources = set()
                    for doc, score in retrieved_docs:
                        src_file = doc.metadata.get("source_file", "Unknown")
                        url = doc.metadata.get("source_url", "")
                        if src_file not in seen_sources:
                            link = f"[{src_file}]({url})" if url else src_file
                            st.markdown(f"- {link} (Confidence Score: {score:.2f})")
                            seen_sources.add(src_file)

            # Append assistant message
            st.session_state.task3_messages.append({"role": "assistant", "content": final_answer})
# Force reload cache 1
# Force reload cache 2