from transformers import pipeline
from config import NER_MODEL_NAME

class MedicalNER:
    def __init__(self):
        try:
            print(f"Loading NER model {NER_MODEL_NAME}...")
            self.ner_pipeline = pipeline("token-classification", model=NER_MODEL_NAME, aggregation_strategy="simple")
        except Exception as e:
            print(f"Error loading NER model: {e}")
            self.ner_pipeline = None

    def extract_and_map(self, query):
        if not self.ner_pipeline:
            return {"Disease/Condition": [], "Symptom": [], "Treatment": []}
            
        try:
            entities = self.ner_pipeline(query)
            
            mapped_entities = {
                "Disease/Condition": set(),
                "Symptom": set(),
                "Treatment": set(),
                "Other": set()
            }
            
            for ent in entities:
                # d4data/biomedical-ner-all has labels like 'Sign_symptom', 'Disease_disorder', 'Medication', 'Diagnostic_procedure', etc.
                label = ent['entity_group']
                word = ent['word'].strip()
                
                # Mapping Layer
                if label in ['Disease_disorder', 'Disease', 'Condition']:
                    mapped_entities["Disease/Condition"].add(word)
                elif label in ['Sign_symptom', 'Symptom']:
                    mapped_entities["Symptom"].add(word)
                elif label in ['Medication', 'Diagnostic_procedure', 'Therapeutic_procedure', 'Treatment']:
                    mapped_entities["Treatment"].add(word)
                else:
                    mapped_entities["Other"].add(word)
                    
            return {k: list(v) for k, v in mapped_entities.items()}
        except Exception as e:
            print(f"NER Extraction Error: {e}")
            return {"Disease/Condition": [], "Symptom": [], "Treatment": []}

if __name__ == "__main__":
    ner = MedicalNER()
    print(ner.extract_and_map("What are the treatments for Type 2 Diabetes and high blood pressure?"))
