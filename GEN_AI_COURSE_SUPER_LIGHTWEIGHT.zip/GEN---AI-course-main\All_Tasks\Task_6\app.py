import streamlit as st
import importlib
import multilingual_bot
importlib.reload(multilingual_bot)
from multilingual_bot import MultilingualBot

# Page Configuration
st.set_page_config(page_title="Task 6: PolyglotBot", layout="wide", page_icon="🌍")

# Custom UI
st.markdown("""
    <style>
    .lang-box {
        padding: 15px;
        border-radius: 10px;
        margin-bottom: 20px;
        text-align: center;
        font-weight: bold;
        font-size: 1.2em;
        background-color: rgba(33, 150, 243, 0.2);
        border: 1px solid #2196F3;
        color: #2196F3;
    }
    </style>
""", unsafe_allow_html=True)

st.title("🌍 Task 6: Multilingual Contextual Chatbot")
st.markdown("*Talk to me in English, Spanish, French, German, or mix them up! I will remember the context seamlessly.*")

# Initialize models and state
@st.cache_resource
def load_bot(cache_buster=1):
    return MultilingualBot()

bot = load_bot(cache_buster=2)

if "task6_messages" not in st.session_state:
    st.session_state.task6_messages = [{"role": "assistant", "content": "Hello! Hola! Bonjour! Hallo! How can I assist you today?"}]
if "latest_lang" not in st.session_state:
    st.session_state.latest_lang = "Ready"

# Layout: Main chat and Sidebar
col_chat, col_sidebar = st.columns([3, 1])

with col_sidebar:
    st.subheader("Language Detected")
    lang = st.session_state.latest_lang
    st.markdown(f'<div class="lang-box">🗣️ {lang}</div>', unsafe_allow_html=True)
    st.caption("The chatbot will automatically respond in the detected language while preserving past memory.")

with col_chat:
    for msg in st.session_state.task6_messages:
        avatar = "🧑‍💻" if msg["role"] == "user" else "🌍"
        with st.chat_message(msg["role"], avatar=avatar):
            st.markdown(msg["content"])

    if query := st.chat_input("Ask a question in any language..."):
        # Append User Message
        st.session_state.task6_messages.append({"role": "user", "content": query})
        with st.chat_message("user", avatar="🧑‍💻"):
            st.markdown(query)
            
        # Analyze Language instantly
        detected_lang = bot.detect_language(query)
        st.session_state.latest_lang = detected_lang
        
        # Display Bot Response
        with st.chat_message("assistant", avatar="🌍"):
            with st.spinner(f"Translating and thinking... ({detected_lang})"):
                final_answer = bot.generate_response(query, detected_lang, st.session_state.task6_messages[:-1])
                st.markdown(final_answer)
                
        st.session_state.task6_messages.append({"role": "assistant", "content": final_answer})
        st.rerun()
