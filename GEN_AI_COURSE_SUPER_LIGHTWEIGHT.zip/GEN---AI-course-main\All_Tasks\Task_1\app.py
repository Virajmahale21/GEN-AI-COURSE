﻿import streamlit as st
import os
import json
from langchain_helper import get_qa_chain, create_vector_db

st.set_page_config(page_title="Dynamic Knowledge Base (Task 1)", page_icon="O", layout="wide")


st.title("💬 DynamicKBChatbot")


# Knowledge Base Status Section
st.sidebar.title("🛠️ Knowledge Base Status")
doc_count = 0
last_updated = "Never"

hash_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "doc_hashes.json")
if os.path.exists(hash_file):
    with open(hash_file, "r") as f:
        hashes = json.load(f)
        doc_count = len(hashes)
        if doc_count > 0:
            latest = max(doc["last_updated"] for doc in hashes.values())
            last_updated = latest[:16].replace("T", " ")

st.sidebar.info(f"**Documents processed:** {doc_count}\n\n**Last updated:** {last_updated}")

btn = st.sidebar.button("♻️ Rebuild Knowledgebase")
if btn:
    with st.sidebar:
        with st.spinner("Rebuilding knowledgebase..."):
            create_vector_db()
        st.success("Rebuild complete!")

if "task1_messages" not in st.session_state:
    st.session_state.task1_messages = [{"role": "assistant", "content": "Hello! I am connected to the dynamic knowledge base. How can I help you?"}]

for msg in st.session_state.task1_messages:
    avatar = "🧑‍💻" if msg["role"] == "user" else "🤖"
    with st.chat_message(msg["role"], avatar=avatar):
        st.markdown(msg["content"])
        if msg.get("sources"):
            st.caption("Sources: " + ", ".join(msg["sources"]))

if question := st.chat_input("Ask a question based on the knowledge base..."):
    st.session_state.task1_messages.append({"role": "user", "content": question})
    with st.chat_message("user", avatar="🧑‍💻"):
        st.markdown(question)

    with st.chat_message("assistant", avatar="🤖"):
        chain = get_qa_chain()
        if chain is None:
            st.error("Knowledge base not found. Please create/update it first.")
        else:
            with st.spinner("Searching Knowledge Base..."):
                response = chain(question)
                ans = response["result"]
                st.markdown(ans)
                
                sources = []
                if "source_documents" in response and response["source_documents"]:
                    seen_sources = set()
                    for doc in response["source_documents"]:
                        source_file = doc.metadata.get("source_file") or doc.metadata.get("source") or "Unknown"
                        if source_file not in seen_sources:
                            sources.append(source_file)
                            seen_sources.add(source_file)
                    
                    if sources:
                        st.caption("Sources: " + ", ".join(sources))
                
                st.session_state.task1_messages.append({"role": "assistant", "content": ans, "sources": sources})