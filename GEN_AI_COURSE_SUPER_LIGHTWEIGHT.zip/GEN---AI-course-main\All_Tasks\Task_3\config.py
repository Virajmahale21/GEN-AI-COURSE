﻿import os
from dotenv import load_dotenv

load_dotenv()

# Directories
DATA_DIR = r"C:\Users\Viraj\Downloads\MedQuAD-master\MedQuAD-master"
VECTORSTORE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vectorstore")

# Ensure vectorstore exists
os.makedirs(VECTORSTORE_DIR, exist_ok=True)

# File Paths
FAISS_INDEX_PATH = os.path.join(VECTORSTORE_DIR, "faiss_index")
METADATA_PATH = os.path.join(VECTORSTORE_DIR, "metadata.json")

# Model configuration
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
NER_MODEL_NAME = "d4data/biomedical-ner-all"
LLM_MODEL_NAME = "gemini-1.5-flash"

# Search configuration
TOP_K = 3
SIMILARITY_THRESHOLD = 0.65  # Distance threshold (for L2, lower is better. Cosine similarity may vary. FAISS L2 requires tuning. We'll implement a custom check.)
