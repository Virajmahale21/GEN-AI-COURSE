﻿import os
from langchain_community.llms import Ollama

class LLMExplainer:
    def __init__(self):
        self.llm = Ollama(model="llama3", temperature=0.2)

    def generate_rag_response(self, query, retrieved_papers, conversation_history, level="Intermediate"):
        if not retrieved_papers:
            return "I could not find sufficient research evidence in the arXiv Computer Science database to safely answer your query. Please rephrase or search for another topic."

        context_str = ""
        citations = []
        for idx, item in enumerate(retrieved_papers):
            meta = item["metadata"]
            authors = ", ".join(meta["authors"][:2]) + (" et al." if len(meta["authors"]) > 2 else "")
            context_str += f"\n--- PAPER {idx+1}: {meta['title']} ({meta['year']}) ---\nAuthors: {authors}\narXiv ID: {meta['paper_id']}\nAbstract: {meta['abstract']}\n"
            citations.append(f"• **{meta['title']}** ({meta['year']}) by {authors} ➝ *arXiv:{meta['paper_id']}*")

        level_instruction = {
            "Beginner": "Explain concepts simply using analogies, everyday examples, and avoiding complex mathematical jargon.",
            "Intermediate": "Provide standard technical explanations using clear computer science terminology and structural steps.",
            "Advanced": "Deliver rigorous, highly technical analysis including mathematical formulations, algorithmic logic, and architecture details."
        }.get(level, "Provide clear technical explanations.")

        prompt = f"""You are an expert Computer Science Research Assistant.
Answer the user's query strictly based on the provided arXiv Research Paper Context and Conversation History below.

STRICT RULE: YOU MUST ONLY ANSWER QUESTIONS BASED ON THE PROVIDED ARXIV CONTEXT.
STRICT RULE: IF THE USER ASKS A GENERAL QUESTION (e.g., 'hello', 'how are you', 'write code in python', 'tell me a joke') OR A QUESTION UNRELATED TO THE CONTEXT, YOU MUST REFUSE TO ANSWER AND EXPLICITLY STATE THAT YOU CAN ONLY ANSWER RESEARCH QUESTIONS COVERED BY THE ARXIV DATASET. Do not generate explanations for topics not present in the context.

[DIFFICULTY LEVEL]:
{level_instruction}

[ARXIV CONTEXT]:
{context_str}

[CONVERSATION HISTORY]:
{conversation_history}

User Query: {query}
Answer:"""
        
        try:
            response = self.llm.invoke(prompt)
            
            # Append citations
            response += "\n\n---\n**Sources Consulted:**\n" + "\n".join(citations)
            return response
        except Exception as e:
            return f"Error communicating with local Ollama LLM: {str(e)}\nMake sure Ollama is running and 'llama3' is pulled."

    def generate_paper_summary(self, paper_meta):
        prompt = f"""Analyze and summarize this research paper into 8 structural components: Background, Objective, Methodology, Architecture, Key Findings, Limitations, Future Work, and Conclusion.

Paper Details:
Title: {paper_meta['title']}
Authors: {', '.join(paper_meta['authors'])}
Abstract: {paper_meta['abstract']}
"""
        try:
            return self.llm.invoke(prompt)
        except Exception as e:
            return f"Error communicating with local Ollama LLM: {str(e)}\nMake sure Ollama is running."