import os
import xml.etree.ElementTree as ET
import glob
import json
try:
    from langchain_core.documents import Document
except ImportError:
    from langchain.schema import Document
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from config import DATA_DIR, FAISS_INDEX_PATH, EMBEDDING_MODEL_NAME, METADATA_PATH

def parse_medquad_xml(xml_path):
    documents = []
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
        
        doc_id = root.attrib.get('id', '')
        source = root.attrib.get('source', '')
        url = root.attrib.get('url', '')
        
        focus_elem = root.find('Focus')
        focus = focus_elem.text if focus_elem is not None else ''
        
        # Extract synonyms and semantic types
        synonyms = []
        semantic_types = []
        cui = ""
        
        focus_annotations = root.find('FocusAnnotations')
        if focus_annotations is not None:
            umls = focus_annotations.find('UMLS')
            if umls is not None:
                cuis = umls.find('CUIs')
                if cuis is not None and cuis.find('CUI') is not None:
                    cui = cuis.find('CUI').text
                    
                stypes = umls.find('SemanticTypes')
                if stypes is not None:
                    for st in stypes.findall('SemanticType'):
                        if st.text:
                            semantic_types.append(st.text)
            
            syn_elem = focus_annotations.find('Synonyms')
            if syn_elem is not None:
                for syn in syn_elem.findall('Synonym'):
                    if syn.text:
                        synonyms.append(syn.text)
        
        qapairs = root.find('QAPairs')
        if qapairs is not None:
            for qapair in qapairs.findall('QAPair'):
                question_elem = qapair.find('Question')
                answer_elem = qapair.find('Answer')
                
                if question_elem is not None and answer_elem is not None and answer_elem.text and answer_elem.text.strip():
                    question_text = question_elem.text.strip()
                    answer_text = answer_elem.text.strip()
                    qtype = question_elem.attrib.get('qtype', '')
                    
                    # Store rich metadata
                    metadata = {
                        "source_file": os.path.basename(xml_path),
                        "source": source,
                        "source_url": url,
                        "focus": focus,
                        "question_type": qtype,
                        "question": question_text,
                        "synonyms": ", ".join(synonyms),
                        "UMLS_CUI": cui,
                        "semantic_type": ", ".join(semantic_types)
                    }
                    
                    # We embed the Question + Answer to capture semantic meaning effectively
                    content = f"Question: {question_text}\nAnswer: {answer_text}"
                    documents.append(Document(page_content=content, metadata=metadata))
    except Exception as e:
        print(f"Error parsing {xml_path}: {e}")
        
    return documents

def build_vectorstore():
    print("Finding XML files...")
    xml_files = glob.glob(os.path.join(DATA_DIR, "**", "*.xml"), recursive=True)
    print(f"Found {len(xml_files)} XML files.")
    
    all_docs = []
    
    # Just parse a subset if you want to save time, or all for production
    # For testing, parsing all might take a few minutes. We'll parse all.
    for i, file_path in enumerate(xml_files):
        if i % 1000 == 0:
            print(f"Parsed {i}/{len(xml_files)} files...")
        docs = parse_medquad_xml(file_path)
        all_docs.extend(docs)
        
    print(f"Total Q&A pairs extracted: {len(all_docs)}")
    
    print("Initializing embedding model...")
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    
    print("Building FAISS index. This might take a while depending on the dataset size...")
    # FAISS will handle everything
    db = FAISS.from_documents(all_docs, embeddings)
    
    print(f"Saving index to {FAISS_INDEX_PATH}")
    db.save_local(FAISS_INDEX_PATH)
    
    # Also save a metadata summary
    with open(METADATA_PATH, "w") as f:
        json.dump({"total_documents": len(all_docs), "model": EMBEDDING_MODEL_NAME}, f)
        
    print("Vectorstore built successfully!")

if __name__ == "__main__":
    build_vectorstore()
