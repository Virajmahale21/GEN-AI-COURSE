import plotly.express as px

def generate_mermaid_concept_graph(paper_title, keywords):
    """Generates Mermaid.js flowchart diagram representing concept relations."""
    title_short = paper_title[:30] + "..." if len(paper_title) > 30 else paper_title
    clean_title = "".join([c for c in title_short if c.isalnum() or c == " "])
    
    mermaid_code = f"""graph TD
    A["📄 {clean_title}"] --> B["Core Domain: Computer Science"]
"""
    for i, kw in enumerate(keywords[:6]):
        clean_kw = "".join([c for c in kw if c.isalnum() or c == " "])
        mermaid_code += f'    A --> C{i}["💡 {clean_kw}"]\n'
        
    return mermaid_code

def create_category_distribution_chart(papers):
    """Generates Plotly bar chart showing distribution of papers across CS subfields."""
    category_counts = {}
    for p in papers:
        for cat in p.get("categories", []):
            category_counts[cat] = category_counts.get(cat, 0) + 1
            
    cats = list(category_counts.keys())
    counts = list(category_counts.values())
    
    fig = px.bar(
        x=cats, 
        y=counts, 
        labels={'x': 'Computer Science Category', 'y': 'Number of Papers'},
        title="Distribution of arXiv Papers by Category",
        color=counts,
        color_continuous_scale="Viridis"
    )
    fig.update_layout(template="plotly_dark")
    return fig
