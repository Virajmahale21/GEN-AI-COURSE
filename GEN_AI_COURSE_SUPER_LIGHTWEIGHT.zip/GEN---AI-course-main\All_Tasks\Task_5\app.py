﻿import streamlit as st
from sentiment_bot import SentimentBot

# Page Configuration
st.set_page_config(page_title="Task 5: SentimentBot", layout="wide", page_icon="💬")

# Custom UI
st.markdown("""
    <style>
    .sentiment-box {
        padding: 15px;
        border-radius: 10px;
        margin-bottom: 20px;
        text-align: center;
        font-weight: bold;
        font-size: 1.2em;
    }
    .Positive { background-color: rgba(76, 175, 80, 0.2); border: 1px solid #4CAF50; color: #4CAF50; }
    .Negative { background-color: rgba(244, 67, 54, 0.2); border: 1px solid #F44336; color: #F44336; }
    .Neutral { background-color: rgba(158, 158, 158, 0.2); border: 1px solid #9E9E9E; color: #9E9E9E; }
    </style>
""", unsafe_allow_html=True)

st.title("💬 Task 5")
st.markdown("*A customer service chatbot that actively detects and responds to your emotional state.*")

# Initialize models and state
@st.cache_resource
def load_bot():
    return SentimentBot()

bot = load_bot()

if "task5_messages" not in st.session_state:
    st.session_state.task5_messages = [{"role": "assistant", "content": "Hello! I am customer support. How can I assist you today?"}]
if "latest_sentiment" not in st.session_state:
    st.session_state.latest_sentiment = ("Neutral", 0.0, "😐")

# Layout: Main chat and Sidebar
col_chat, col_sidebar = st.columns([3, 1])

with col_sidebar:
    st.subheader("Live Sentiment Meter")
    cat, score, emoji = st.session_state.latest_sentiment
    st.markdown(f'<div class="sentiment-box {cat}">{emoji} {cat} ({score:.2f})</div>', unsafe_allow_html=True)
    st.caption("The chatbot detects your emotion to shape its response.")

with col_chat:
    for msg in st.session_state.task5_messages:
        avatar = "🧑‍💻" if msg["role"] == "user" else "🤖"
        with st.chat_message(msg["role"], avatar=avatar):
            st.markdown(msg["content"])

    if query := st.chat_input("Type your message here..."):
        # Append User Message
        st.session_state.task5_messages.append({"role": "user", "content": query})
        with st.chat_message("user", avatar="🧑‍💻"):
            st.markdown(query)
            
        # Analyze Sentiment instantly
        category, polarity, emoji = bot.analyze_sentiment(query)
        st.session_state.latest_sentiment = (category, polarity, emoji)
        
        # Display Bot Response
        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner(f"Agent is typing... (Detected {category} Tone)"):
                final_answer = bot.generate_response(query, category, st.session_state.task5_messages[:-1])
                st.markdown(final_answer)
                
        st.session_state.task5_messages.append({"role": "assistant", "content": final_answer})
        st.rerun()