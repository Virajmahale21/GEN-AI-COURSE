﻿import streamlit as st
import os
import json
from langchain_helper import create_vector_db, get_multimodal_answer

st.set_page_config(page_title="Multi-Modal Assistant (Task 2)", page_icon="👁️", layout="wide")


st.title("💬 MultiModalChatbot")


# Sidebar
st.sidebar.title("🖼️ Visual Input")
image_file = st.sidebar.file_uploader("Upload an Image (Optional)", type=["jpg", "jpeg", "png"])
image_bytes = None
if image_file:
    image_bytes = image_file.getvalue()
    st.sidebar.image(image_file, caption="Uploaded Image", use_column_width=True)

# Chat History
if "task2_messages" not in st.session_state:
    st.session_state.task2_messages = [{"role": "assistant", "content": "Hello! You can ask me text questions or upload an image and ask about it."}]

for msg in st.session_state.task2_messages:
    avatar = "🧑‍💻" if msg["role"] == "user" else "🤖"
    with st.chat_message(msg["role"], avatar=avatar):
        st.markdown(msg["content"])
        if msg.get("image"):
            st.image(msg["image"])
        if msg.get("sources"):
            st.caption("Evidence Sources: " + ", ".join(msg["sources"]))

if question := st.chat_input("Ask a question (text or image)..."):
    # Append user message
    st.session_state.task2_messages.append({"role": "user", "content": question, "image": image_bytes})
    with st.chat_message("user", avatar="🧑‍💻"):
        st.markdown(question)
        if image_bytes:
            st.image(image_bytes)

    # Generate assistant response
    with st.chat_message("assistant", avatar="🤖"):
        with st.spinner("Analyzing text & visual inputs..."):
            try:
                response = get_multimodal_answer(question, image_bytes, st.session_state.task2_messages[:-1])
                ans = response["result"]
                st.markdown(ans)
                
                sources = []
                # Display source information
                if "source_documents" in response and response["source_documents"]:
                    seen_sources = set()
                    for doc in response["source_documents"]:
                        source_file = doc.metadata.get("source_file") or doc.metadata.get("source") or "Unknown"
                        if source_file not in seen_sources:
                            sources.append(source_file)
                            seen_sources.add(source_file)
                    
                    if sources:
                        st.caption("Evidence Sources: " + ", ".join(sources))
                
                st.session_state.task2_messages.append({"role": "assistant", "content": ans, "sources": sources})
            except Exception as e:
                st.error(f"Error generating response: {e}")