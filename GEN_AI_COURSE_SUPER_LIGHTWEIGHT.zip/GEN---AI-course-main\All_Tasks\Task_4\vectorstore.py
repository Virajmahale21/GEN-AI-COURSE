import os
import json
import pickle
try:
    from langchain_core.documents import Document
except ImportError:
    from langchain.schema import Document
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

from config import PAPERS_JSON_PATH, FAISS_INDEX_PATH, METADATA_PATH, EMBEDDING_MODEL_NAME
from info_extractor import InformationExtractor
from data_prep import fetch_arxiv_cs_papers

def build_vector_store():
    # Ensure data exists
    if not os.path.exists(PAPERS_JSON_PATH):
        print("Dataset file not found. Running data preparation pipeline...")
        fetch_arxiv_cs_papers(max_results=300)
        
    with open(PAPERS_JSON_PATH, "r", encoding="utf-8") as f:
        raw_papers = json.load(f)
        
    extractor = InformationExtractor()
    documents = []
    metadata_store = {}
    
    print("Extracting metadata and building vector embeddings...")
    for paper in raw_papers:
        meta = extractor.extract_paper_metadata(paper)
        paper_id = meta["paper_id"]
        metadata_store[paper_id] = meta
        
        # Formulate search document text
        keywords_str = ", ".join(meta["keywords"])
        authors_str = ", ".join(meta["authors"][:3])
        page_content = f"Title: {meta['title']}\nAuthors: {authors_str}\nKeywords: {keywords_str}\nAbstract: {meta['abstract']}"
        
        doc = Document(
            page_content=page_content,
            metadata=meta
        )
        documents.append(doc)
        
    print(f"Loaded {len(documents)} paper documents for embedding.")
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    
    print("Building FAISS vector index...")
    db = FAISS.from_documents(documents, embeddings)
    db.save_local(FAISS_INDEX_PATH)
    
    with open(METADATA_PATH, "wb") as f:
        pickle.dump(metadata_store, f)
        
    print(f"FAISS index saved successfully to {FAISS_INDEX_PATH}")
    return db, metadata_store

def load_vector_store():
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    if os.path.exists(FAISS_INDEX_PATH):
        db = FAISS.load_local(FAISS_INDEX_PATH, embeddings, allow_dangerous_deserialization=True)
        metadata_store = {}
        if os.path.exists(METADATA_PATH):
            with open(METADATA_PATH, "rb") as f:
                metadata_store = pickle.load(f)
        return db, metadata_store
    else:
        return build_vector_store()

if __name__ == "__main__":
    build_vector_store()
