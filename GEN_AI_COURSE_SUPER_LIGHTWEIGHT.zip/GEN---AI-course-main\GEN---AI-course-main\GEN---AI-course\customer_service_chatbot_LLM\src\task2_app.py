import streamlit as st
import os
import json
from langchain_helper import create_vector_db, get_multimodal_answer

st.set_page_config(page_title="MultiModalChatbot", page_icon="🖼️", layout="wide")

st.title("🖼️ MultiModalChatbot")
st.markdown("*Task 2: Multi-Modal AI Assistant with Vision & Memory*")

# Sidebar
st.sidebar.title("Configuration")
image_file = st.sidebar.file_uploader("Upload an Image (Optional)", type=["jpg", "jpeg", "png"])
image_bytes = None
if image_file:
    image_bytes = image_file.getvalue()
    st.sidebar.image(image_file, caption="Uploaded Image", use_column_width=True)

# Chat History
if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("image"):
            st.image(msg["image"])

if question := st.chat_input("Ask a question (text or image)..."):
    # Append user message
    st.session_state.messages.append({"role": "user", "content": question, "image": image_bytes})
    with st.chat_message("user"):
        st.markdown(question)
        if image_bytes:
            st.image(image_bytes)

    # Generate assistant response
    with st.chat_message("assistant"):
        with st.spinner("Analyzing text & visual inputs..."):
            try:
                response = get_multimodal_answer(question, image_bytes, st.session_state.messages[:-1])
                st.markdown(response["result"])
                
                # Display source information
                if "source_documents" in response and response["source_documents"]:
                    st.subheader("Evidence Sources:")
                    seen_sources = set()
                    for doc in response["source_documents"]:
                        source_file = doc.metadata.get("source_file") or doc.metadata.get("source") or "Unknown"
                        if source_file not in seen_sources:
                            st.write(f"- {source_file}")
                            seen_sources.add(source_file)
                
                st.session_state.messages.append({"role": "assistant", "content": response["result"]})
            except Exception as e:
                st.error(f"Error generating response: {e}")
