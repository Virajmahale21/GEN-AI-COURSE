﻿import os

files_to_update = {
    'Task_1': 'DynamicKBChatbot',
    'Task_2': 'MultiModalChatbot',
    'Task_3': 'MedChatbot',
    'Task_4': 'ArxivExpertChatbot'
}

for task_dir, bot_name in files_to_update.items():
    file_path = f"C:\\Users\\Viraj\\Downloads\\Final_Tasks\\{task_dir}\\app.py"
    if not os.path.exists(file_path):
        continue
        
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
    import re
    # Remove custom CSS block
    content = re.sub(r'st\.markdown\(.*?<style>.*?</style>.*?\)\n', '', content, flags=re.DOTALL)
    
    # Replace title
    content = re.sub(r'st\.title\(.*?\)', f'st.title("💬 {bot_name}")', content)
    
    # Remove task subheaders
    content = re.sub(r'st\.markdown\("### \*Task.*?\)\n', '', content)
    
    # Fix avatars if they are broken
    content = content.replace('avatar="🧑‍💻"', 'avatar="🧑‍💻"')
    content = content.replace('avatar="🤖"', 'avatar="🤖"')
    content = content.replace('avatar="dY ??dY\'"', 'avatar="🧑‍💻"')
    content = content.replace('avatar="dY -"', 'avatar="🤖"')
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)