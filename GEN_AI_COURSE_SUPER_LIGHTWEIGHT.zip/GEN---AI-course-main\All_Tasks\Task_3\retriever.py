﻿import os
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from config import FAISS_INDEX_PATH, EMBEDDING_MODEL_NAME, TOP_K, SIMILARITY_THRESHOLD

class MedicalRetriever:
    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL_NAME)
        self.vectorstore = None
        if os.path.exists(FAISS_INDEX_PATH):
            try:
                self.vectorstore = FAISS.load_local(FAISS_INDEX_PATH, self.embeddings, allow_dangerous_deserialization=True)
            except Exception as e:
                print(f"Error loading FAISS index: {e}")

    def retrieve(self, query):
        if not self.vectorstore:
            return None, f"Vector database not initialized. Path: {FAISS_INDEX_PATH}"
            
        results = self.vectorstore.similarity_search_with_score(query, k=TOP_K)
        
        valid_docs = []
        for doc, score in results:
            if score < SIMILARITY_THRESHOLD:
                valid_docs.append((doc, score))
                
        if not valid_docs:
            return None, "I could not find any highly relevant medical information for this query."
            
        return valid_docs, "Success"