import os
from langdetect import detect, detect_langs
from langchain_community.llms import Ollama

class MultilingualBot:
    def __init__(self):
        # We use the reliable local Ollama instance with llama3
        # Llama3 inherently understands English, Spanish, French, German, etc.
        self.llm = Ollama(model="llama3", temperature=0.3)

    def detect_language(self, text):
        """Detects the primary language of the text."""
        try:
            # Get the primary language code
            lang_code = detect(text)
            
            # Map common codes to full names for the UI
            lang_map = {
                'en': 'English',
                'es': 'Spanish',
                'fr': 'French',
                'de': 'German',
                'it': 'Italian',
                'pt': 'Portuguese',
                'zh-cn': 'Chinese',
                'hi': 'Hindi',
                'ja': 'Japanese',
                'ko': 'Korean',
                'ru': 'Russian',
                'nl': 'Dutch'
            }
            return lang_map.get(lang_code, f"Language Code: {lang_code.upper()}")
        except Exception:
            return "Unknown / Mixed"

    def generate_response(self, user_message, detected_lang, chat_history):
        """Generates a contextual response maintaining the requested language."""
        
        # Base System Prompt ensuring cross-lingual reasoning
        system_prompt = f"""You are PolyglotBot, an intelligent multilingual assistant. 
CRITICAL INSTRUCTIONS:
1. You must understand and maintain context across the entire conversation history, regardless of what languages were used in previous turns.
2. If the user asks a question in a specific language, you MUST reply in that exact same language (e.g., if they ask in Spanish, reply in Spanish). The current detected language is: {detected_lang}.
3. NEW RULE: If you are responding in a language other than English, you MUST ALSO provide a full English translation of your response underneath it. Format it clearly like this:
   [Response in foreign language]
   
   *English Translation:*
   [Response in English]
4. If the user uses mixed languages (code-switching), respond naturally in the primary language they are using, and provide the English translation if the primary language is not English.
5. Ensure your translations and responses sound natural and grammatically correct."""

        # Format Chat History
        history_str = ""
        for msg in chat_history[-6:]: # Keep last 6 messages for context
            history_str += f"{msg['role'].capitalize()}: {msg['content']}\n"

        prompt = f"""{system_prompt}\n\nChat History:\n{history_str}\nUser: {user_message}\nAgent:"""

        try:
            response = self.llm.invoke(prompt)
            return response.strip()
        except Exception as e:
            return f"Error communicating with local Ollama LLM: {str(e)}\nPlease make sure Ollama is running."
