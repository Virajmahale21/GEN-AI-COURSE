import os
from textblob import TextBlob
from langchain_community.llms import Ollama

class SentimentBot:
    def __init__(self):
        self.llm = Ollama(model="llama3", temperature=0.6)

    def analyze_sentiment(self, text):
        """Analyzes the sentiment of the user input and returns a category and score."""
        blob = TextBlob(text)
        polarity = blob.sentiment.polarity
        
        if polarity < -0.1:
            category = "Negative"
            emoji = "😠"
        elif polarity > 0.1:
            category = "Positive"
            emoji = "😊"
        else:
            category = "Neutral"
            emoji = "😐"
            
        return category, polarity, emoji

    def generate_response(self, user_message, sentiment_category, chat_history):
        """Generates a response tailored to the user's emotional state."""
        
        system_prompt = "You are a customer support agent for a technology company. You are helpful, professional, and concise.\n\n"
        
        if sentiment_category == "Negative":
            system_prompt += "CRITICAL INSTRUCTION: The user is upset or frustrated. You MUST be highly empathetic, apologize for their bad experience, and immediately offer solutions to de-escalate the situation. Be extremely polite."
        elif sentiment_category == "Positive":
            system_prompt += "CRITICAL INSTRUCTION: The user is happy or satisfied. You MUST match their enthusiasm, thank them warmly for their positivity, and ensure they feel valued."
        else:
            system_prompt += "CRITICAL INSTRUCTION: The user's tone is neutral. Keep your response professional, objective, and directly address their needs without being overly emotional."

        history_str = ""
        for msg in chat_history[-5:]:
            history_str += f"{msg['role'].capitalize()}: {msg['content']}\n"

        prompt = f"""{system_prompt}\n\nChat History:\n{history_str}\nUser: {user_message}\nAgent:"""

        try:
            response = self.llm.invoke(prompt)
            return response.strip()
        except Exception as e:
            return f"Error communicating with local Ollama LLM: {str(e)}\nPlease make sure Ollama is running."