﻿import os
from langchain_community.llms import Ollama

class LLMService:
    def __init__(self):
        self.llm = Ollama(model="llama3", temperature=0.1)

    def generate_response(self, query, image_bytes, retrieved_docs, chat_history):
        # Strict Guardrails
        guardrails = """
MEDICAL SAFETY GUARDRAILS & DATASET STRICTNESS:
- You are a medical assistant utilizing the MedQuAD dataset.
- This information is for informational purposes only.
- DO NOT provide diagnoses.
- DO NOT provide personalized prescriptions.
- DO NOT make emergency decision-making recommendations.
- Always encourage professional medical consultation when appropriate.
- STRICT RULE: YOU MUST ONLY ANSWER QUESTIONS BASED ON THE PROVIDED MEDQUAD CONTEXT. 
- STRICT RULE: IF THE USER ASKS A GENERAL QUESTION (e.g., 'hello', 'who are you', 'what is 2+2', 'write a poem', 'tell me a joke') OR A QUESTION UNRELATED TO THE CONTEXT, YOU MUST REFUSE TO ANSWER AND EXPLICITLY STATE THAT YOU CAN ONLY ANSWER MEDICAL QUESTIONS COVERED BY THE MEDQUAD DATASET. Do not provide any other information.
"""

        context_str = ""
        if retrieved_docs:
            context_pieces = []
            for idx, (doc, score) in enumerate(retrieved_docs):
                context_pieces.append(f"--- Document {idx+1} (Source: {doc.metadata.get('source_file')}) ---\n{doc.page_content}")
            context_str = "\n".join(context_pieces)

        system_instruction = f"""{guardrails}\n\nRETRIEVED MEDQUAD CONTEXT:\n{context_str}\n\nIf the retrieved context does not contain the answer, politely state that you do not have enough information based on the MedQuAD dataset.\n"""
        
        # Build prompt manually for Ollama
        prompt = system_instruction + "\n\nUser Question: " + query + "\nAnswer: "
        
        try:
            response = self.llm.invoke(prompt)
            return response
        except Exception as e:
            return f"Error communicating with local Ollama LLM: {str(e)}\nMake sure Ollama is running and 'llama3' is pulled."