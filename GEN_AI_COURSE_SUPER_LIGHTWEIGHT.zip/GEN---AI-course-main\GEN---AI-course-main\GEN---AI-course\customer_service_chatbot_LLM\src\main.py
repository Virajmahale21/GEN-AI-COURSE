import streamlit as st
import os
import json
from langchain_helper import get_qa_chain, create_vector_db, get_multimodal_answer

st.set_page_config(page_title="AI Chatbot Suite", page_icon="🤖", layout="wide")

# Sidebar navigation mode
st.sidebar.title("Select Application Mode")
app_mode = st.sidebar.radio("Choose Mode:", ["DynamicKBChatbot", "MultiModalChatbot"])

if app_mode == "DynamicKBChatbot":
    st.title("📚 DynamicKBChatbot")
    st.markdown("*Task 1: Dynamically Expanding Knowledge Base System*")

    # Knowledge Base Status Section
    st.sidebar.markdown("---")
    st.sidebar.title("Knowledge Base Status")
    doc_count = 0
    last_updated = "Never"

    hash_file = "../doc_hashes.json"
    if os.path.exists(hash_file):
        with open(hash_file, "r") as f:
            hashes = json.load(f)
            doc_count = len(hashes)
            if doc_count > 0:
                latest = max(doc["last_updated"] for doc in hashes.values())
                last_updated = latest[:16].replace("T", " ")

    st.sidebar.markdown(f"**Documents processed:** {doc_count}")
    st.sidebar.markdown(f"**Last updated:** {last_updated}")
    st.sidebar.markdown("**Status:** Up to date")

    btn = st.sidebar.button("Create/Reset Knowledgebase")
    if btn:
        create_vector_db()
        st.sidebar.success("Reset Knowledgebase complete!")

    question = st.text_input("Question: ")

    if question:
        chain = get_qa_chain()
        if chain is None:
            st.error("Knowledge base not found. Please create/update it first.")
        else:
            with st.spinner("Searching Knowledge Base..."):
                response = chain(question)

                st.header("Answer")
                st.write(response["result"])
                
                if "source_documents" in response and response["source_documents"]:
                    st.subheader("Retrieved Sources:")
                    seen_sources = set()
                    for doc in response["source_documents"]:
                        source_file = doc.metadata.get("source_file") or doc.metadata.get("source") or "Unknown"
                        if source_file not in seen_sources:
                            st.write(f"- {source_file}")
                            seen_sources.add(source_file)

else:
    st.title("🖼️ MultiModalChatbot")
    st.markdown("*Task 2: Multi-Modal AI Assistant with Vision & Memory*")

    st.sidebar.markdown("---")
    image_file = st.sidebar.file_uploader("Upload an Image (Optional)", type=["jpg", "jpeg", "png"])
    image_bytes = None
    if image_file:
        image_bytes = image_file.getvalue()
        st.sidebar.image(image_file, caption="Uploaded Image", use_column_width=True)

    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg.get("image"):
                st.image(msg["image"])

    if question := st.chat_input("Ask a question (text or image)..."):
        st.session_state.messages.append({"role": "user", "content": question, "image": image_bytes})
        with st.chat_message("user"):
            st.markdown(question)
            if image_bytes:
                st.image(image_bytes)

        with st.chat_message("assistant"):
            with st.spinner("Analyzing text & visual inputs..."):
                try:
                    response = get_multimodal_answer(question, image_bytes, st.session_state.messages[:-1])
                    st.markdown(response["result"])
                    
                    if "source_documents" in response and response["source_documents"]:
                        st.subheader("Evidence Sources:")
                        seen_sources = set()
                        for doc in response["source_documents"]:
                            source_file = doc.metadata.get("source_file") or doc.metadata.get("source") or "Unknown"
                            if source_file not in seen_sources:
                                st.write(f"- {source_file}")
                                seen_sources.add(source_file)
                    
                    st.session_state.messages.append({"role": "assistant", "content": response["result"]})
                except Exception as e:
                    st.error(f"Error generating response: {e}")


