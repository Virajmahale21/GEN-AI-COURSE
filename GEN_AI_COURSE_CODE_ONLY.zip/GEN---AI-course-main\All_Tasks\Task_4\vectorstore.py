﻿import json
import os
import pickle
from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from config import PAPERS_JSON_PATH, VECTORSTORE_DIR, FAISS_INDEX_PATH, METADATA_PATH, EMBEDDING_MODEL_NAME

def build_vectorstore():
    print("Building FAISS VectorStore for arXiv papers...")
    
    if not os.path.exists(PAPERS_JSON_PATH):
        print("Papers JSON not found. Run data_prep.py first.")
        return

    with open(PAPERS_JSON_PATH, 'r', encoding='utf-8') as f:
        papers = json.load(f)

    documents = []
    metadata_store = {}

    for p in papers:
        # Combine title and abstract for embedding
        content = f"Title: {p['title']}\nAbstract: {p['abstract']}"
        doc = Document(page_content=content, metadata={"paper_id": p['paper_id']})
        documents.append(doc)
        
        # Store full metadata for retrieval
        metadata_store[p['paper_id']] = p

    # Create Embeddings
    embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL_NAME)
    
    # Build FAISS
    vectorstore = FAISS.from_documents(documents, embeddings)
    vectorstore.save_local(FAISS_INDEX_PATH)
    print(f"FAISS index saved to {FAISS_INDEX_PATH}")

    # Save Metadata Mapping
    with open(METADATA_PATH, 'wb') as f:
        pickle.dump(metadata_store, f)
    print(f"Metadata saved to {METADATA_PATH}")

if __name__ == "__main__":
    build_vectorstore()