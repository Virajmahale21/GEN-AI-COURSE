﻿import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Pointing directly to the cloned GitHub dataset inside this folder
DATA_DIR = os.path.join(BASE_DIR, "MedQuAD")
VECTORSTORE_DIR = os.path.join(BASE_DIR, "vectorstore")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(VECTORSTORE_DIR, exist_ok=True)

FAISS_INDEX_PATH = os.path.join(VECTORSTORE_DIR, "faiss_index")
METADATA_PATH = os.path.join(VECTORSTORE_DIR, "metadata.pkl")

EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
OLLAMA_MODEL_NAME = "llama3"
TOP_K = 3
SIMILARITY_THRESHOLD = 1.2